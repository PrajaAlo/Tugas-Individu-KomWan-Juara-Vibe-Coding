import { useState, useEffect } from "react";
import { X, Save, Settings } from "lucide-react";
import { motion } from "motion/react";
import { useAuth, UserProfile } from "../contexts/AuthContext";

interface ProfileSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ProfileSettings({ isOpen, onClose }: ProfileSettingsProps) {
  const { profile, updateProfile } = useAuth();
  const [tempProfile, setTempProfile] = useState<Partial<UserProfile>>({});

  useEffect(() => {
    if (profile) setTempProfile(profile);
  }, [profile, isOpen]);

  const handleSaveSettings = async () => {
    // Recalculate TDEE and nutritional targets when saving physical profile data
    let weight = tempProfile.weight || 0;
    let height = tempProfile.height || 0;
    let age = tempProfile.age || 0;
    let gender = tempProfile.gender || 'male';
    let activityLevel = tempProfile.activityLevel || 1.2;
    let healthGoal = tempProfile.healthGoal || 'maintenance';

    // Mifflin-St Jeor Equation
    let bmr = (10 * weight) + (6.25 * height) - (5 * age);
    bmr += gender === 'male' ? 5 : -161;
    let tdee = bmr * activityLevel;
    
    if (healthGoal === 'weight_loss') tdee -= 500;
    else if (healthGoal === 'muscle_building') tdee += 500;

    let calories = Math.max(1200, Math.round(tdee));
    
    // Macro split
    let protein = Math.round(weight * 1.6); // 1.6g per kg of bodyweight
    let fat = Math.round((calories * 0.25) / 9); // 25% from fat
    let carbs = Math.round((calories - (protein * 4) - (fat * 9)) / 4); // remainder from carbs

    await updateProfile({
      ...tempProfile,
      dailyTargets: {
        ...tempProfile.dailyTargets,
        calories,
        protein,
        carbs,
        fat,
        fiber: 25,
        sodium: 2300,
        sugar: 50
      }
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm dark:bg-black/60 animate-in fade-in duration-200">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md shadow-xl border border-[#EDF2F0] dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="flex justify-between items-center p-6 border-b border-[#EDF2F0] dark:border-slate-800 shrink-0">
          <h2 className="text-xl font-bold flex items-center gap-2 text-[#1B4332] dark:text-emerald-50">
            <Settings className="w-5 h-5" /> Data Fisik & Tujuan
          </h2>
          <button onClick={onClose} className="text-[#95A5A6] hover:text-[#2D3436] dark:hover:text-slate-200 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Nama Panggilan</label>
              <input 
                type="text" 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.displayName || ""}
                onChange={e => setTempProfile({...tempProfile, displayName: e.target.value})}
              />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Jenis Kelamin</label>
              <select 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.gender || "male"}
                onChange={e => setTempProfile({...tempProfile, gender: e.target.value as any})}
              >
                <option value="male">Laki-laki</option>
                <option value="female">Perempuan</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Umur</label>
              <input 
                type="number" 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.age || 0}
                onChange={e => setTempProfile({...tempProfile, age: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Berat Badan (kg)</label>
              <input 
                type="number" 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.weight || 0}
                onChange={e => setTempProfile({...tempProfile, weight: Number(e.target.value)})}
              />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Tinggi Badan (cm)</label>
              <input 
                type="number" 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.height || 0}
                onChange={e => setTempProfile({...tempProfile, height: Number(e.target.value)})}
              />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Tingkat Aktivitas (Multiplier)</label>
              <select 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.activityLevel || 1.2}
                onChange={e => setTempProfile({...tempProfile, activityLevel: Number(e.target.value)})}
              >
                <option value={1.2}>1.2 (Sangat jarang berolahraga)</option>
                <option value={1.375}>1.375 (Olahraga ringan)</option>
                <option value={1.55}>1.55 (Olahraga sedang)</option>
                <option value={1.725}>1.725 (Olahraga berat)</option>
                <option value={1.9}>1.9 (Sangat berat/atlet)</option>
              </select>
            </div>
            <div className="col-span-2">
              <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">Tujuan Kesehatan</label>
              <select 
                className="w-full mt-1 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl p-3 text-[#2D3436] dark:text-slate-200"
                value={tempProfile.healthGoal || "maintenance"}
                onChange={e => setTempProfile({...tempProfile, healthGoal: e.target.value as any})}
              >
                <option value="weight_loss">Weight Loss (Turun Berat Badan)</option>
                <option value="maintenance">Maintenance (Jaga Berat Badan)</option>
                <option value="muscle_building">Muscle Build (Naik Massa Otot / BB)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-[#EDF2F0] dark:border-slate-800 shrink-0 flex gap-3">
            <button 
              onClick={handleSaveSettings}
              className="flex-1 py-3 px-4 rounded-xl font-semibold text-white bg-[#40916C] hover:bg-[#2D6A4F] dark:bg-emerald-600 dark:hover:bg-emerald-700 transition-colors flex justify-center items-center gap-2 shadow-sm"
            >
              <Save className="w-4 h-4" /> Simpan Profil
            </button>
        </div>
      </motion.div>
    </div>
  );
}
