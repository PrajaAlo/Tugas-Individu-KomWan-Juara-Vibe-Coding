import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

export interface NutritionData {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sodium: number;
  sugar: number;
  consumed?: boolean;
}

interface NutritionChartProps {
  data: NutritionData;
  dailyTargets: NutritionData;
}

const LABELS: Record<keyof NutritionData, string> = {
  calories: "Kalori",
  protein: "Protein",
  carbs: "Karbohidrat",
  fat: "Lemak",
  fiber: "Serat",
  sodium: "Natrium",
  sugar: "Gula",
};

const FORMATS: Record<keyof NutritionData, string> = {
  calories: "kkal",
  protein: "g",
  carbs: "g",
  fat: "g",
  fiber: "g",
  sodium: "mg",
  sugar: "g",
};

const NutritionChart: React.FC<NutritionChartProps> = ({ data, dailyTargets }) => {
  const chartData = (Object.keys(dailyTargets) as Array<keyof NutritionData>).map((key) => {
    const value = data[key] || 0;
    const target = dailyTargets[key];
    const percentage = Math.min((value / target) * 100, 100);
    
    // Determine color based on percentage to warn on high sodium/sugar/calories
    let color = "#40916C"; // Default emerald
    if (key === "sodium" || key === "sugar" || key === "fat") {
      if (percentage > 80) color = "#E67E22"; // Orange alert
      if (percentage >= 100) color = "#C0392B"; // Red danger
    } else if (key === "calories") {
      if (percentage > 50) color = "#3b82f6"; // Blue info
      if (percentage > 80) color = "#E67E22";
    }

    return {
      name: LABELS[key],
      value: percentage,
      actualAmount: value,
      unit: FORMATS[key],
    };
  });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 border border-[#EDF2F0] dark:border-slate-700 p-3 rounded-xl shadow-lg">
          <p className="font-semibold text-sm text-[#1B4332] dark:text-emerald-50 mb-1">{label}</p>
          <p className="text-xs text-[#525B58] dark:text-slate-400">
            Kandungan: <span className="font-bold text-[#2D3436] dark:text-slate-200">{dataPoint.actualAmount}{dataPoint.unit}</span>
          </p>
          <p className="text-xs text-[#525B58] dark:text-slate-400">
            Kecukupan: <span className="font-bold text-[#2D3436] dark:text-slate-200">{Math.round(dataPoint.value)}%</span> dari harian
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-64 mt-4 bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-2xl p-4 shadow-sm transition-colors">
      <h3 className="text-sm font-bold text-[#1B4332] dark:text-emerald-50 mb-4 px-2">
        📊 Persentase Kecukupan Gizi Harian
      </h3>
      <ResponsiveContainer width="100%" height="80%">
        <BarChart
          data={chartData}
          layout="vertical"
          margin={{ top: 0, right: 30, left: 30, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#EDF2F0" opacity={0.5} />
          <XAxis 
            type="number" 
            domain={[0, 100]} 
            hide
          />
          <YAxis 
            dataKey="name" 
            type="category" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fontSize: 12, fill: "#525B58" }} 
            width={75}
          />
          <Tooltip cursor={{ fill: "transparent" }} content={<CustomTooltip />} />
          <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={16}>
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color || "#40916C"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default NutritionChart;
