import { useState, useRef, useEffect } from "react";
import { Send, Image as ImageIcon, X, ChefHat, Loader2, Moon, Sun, Trash2, Settings2, Save, ArrowLeft } from "lucide-react";
import { Link, Navigate } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { motion } from "motion/react";
import { Content } from "../types";
import NutritionChart, { NutritionData } from "../components/NutritionChart";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";

const extractNutritionData = (text: string): { data: NutritionData | null; cleanText: string } => {
  const match = text.match(/```json\n([\s\S]*?)\n```/);
  if (match && match[1]) {
    try {
      const data = JSON.parse(match[1]);
      const cleanText = text.replace(match[0], '').trim();
      return { data, cleanText };
    } catch (e) {
      return { data: null, cleanText: text };
    }
  }
  return { data: null, cleanText: text };
};

const DEFAULT_TARGETS: NutritionData = {
  calories: 2000,
  protein: 60,
  carbs: 300,
  fat: 65,
  fiber: 30,
  sodium: 2000,
  sugar: 50,
};

export default function ChatPage() {
  const { user, profile, updateProfile } = useAuth();
  const { isDarkMode, toggleDarkMode } = useTheme();
  
  const [history, setHistory] = useState<Content[]>(() => {
    try {
      const saved = localStorage.getItem("nutri_chat_history");
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [input, setInput] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // User Profile State
  const dailyTargets = profile?.dailyTargets || DEFAULT_TARGETS;
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [tempTargets, setTempTargets] = useState<NutritionData>(dailyTargets);

  useEffect(() => {
    if (profile) setTempTargets(profile.dailyTargets);
  }, [profile]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem("nutri_chat_history", JSON.stringify(history));
  }, [history]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [history, isLoading]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const url = URL.createObjectURL(file);
      setImagePreview(url);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
      setImagePreview(null);
    }
  };

  const handleSaveProfile = async () => {
    await updateProfile({ dailyTargets: tempTargets });
    setIsProfileModalOpen(false);
  };

  if (!user || !profile) {
    return <Navigate to="/login" replace />;
  }

  const markAsConsumed = (index: number) => {
    setHistory((prev) => {
      const newHistory = [...prev];
      const msg = newHistory[index];
      if (msg && msg.role === "model") {
        const text = msg.parts[0].text;
        if (text) {
          const newText = text.replace(/```json\n([\s\S]*?)\n```/, (match, p1) => {
            try {
              const data = JSON.parse(p1);
              data.consumed = true;
              return `\`\`\`json\n${JSON.stringify(data, null, 2)}\n\`\`\``;
            } catch (e) {
              return match;
            }
          });
          newHistory[index] = {
            ...msg,
            parts: [{ text: newText }],
          };
        }
      }
      return newHistory;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !imageFile) || isLoading) return;

    let base64 = "";
    let mimeType = "";

    if (imageFile) {
      mimeType = imageFile.type;
      base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(imageFile);
        reader.onload = () => resolve((reader.result as string).split(",")[1]);
        reader.onerror = (error) => reject(error);
      });
    }

    const newMessage = input.trim();
    const newUserContent: Content = {
      role: "user",
      parts: [],
      timestamp: Date.now(),
    };

    if (base64) {
      newUserContent.parts.push({
        inlineData: { data: base64, mimeType },
      });
    }
    if (newMessage) {
      newUserContent.parts.push({ text: newMessage });
    }

    setHistory((prev) => [...prev, newUserContent]);
    setInput("");
    removeImage();
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          history, // Send current history
          message: newMessage,
          imageBase64: base64 || undefined,
          mimeType: mimeType || undefined,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setHistory((prev) => [
          ...prev,
          {
            role: "model",
            parts: [{ text: data.text }],
            timestamp: Date.now(),
          },
        ]);
      } else {
        setHistory((prev) => [
          ...prev,
          {
            role: "model",
            parts: [{ text: "**Error:** " + (data.error || "Gagal menghubungi asisten.") }],
            timestamp: Date.now(),
          },
        ]);
      }
    } catch (err) {
      setHistory((prev) => [
        ...prev,
        {
          role: "model",
          parts: [{ text: "**Error:** Terjadi kesalahan jaringan." }],
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#F9FAF8] dark:bg-slate-950 font-sans text-[#2D3436] dark:text-slate-200 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-[#EDF2F0] dark:border-slate-800 px-4 md:px-8 py-4 flex justify-between items-center shrink-0 sticky top-0 z-40 transition-colors">
        <div className="flex gap-2">
           <Link
            to="/"
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium text-[#525B58] dark:text-slate-400 hover:bg-[#F0F2F1] dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Kembali</span>
          </Link>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#40916C] dark:bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-sm transition-colors">
            <ChefHat className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-[#1B4332] dark:text-emerald-50">
            Nutri <span className="text-[#74C69D] dark:text-emerald-400 font-normal">AI</span>
          </h1>
        </div>
        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button
              onClick={() => setHistory([])}
              className="w-10 h-10 flex items-center justify-center rounded-xl text-[#95A5A6] dark:text-slate-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-[#F0F2F1] dark:hover:bg-slate-800 transition-colors"
              aria-label="Clear chat"
              title="Bersihkan Chat"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={toggleDarkMode}
            className="w-10 h-10 flex items-center justify-center rounded-xl text-[#95A5A6] dark:text-slate-400 hover:bg-[#F0F2F1] dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle dark mode"
          >
            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-6 w-full max-w-4xl mx-auto space-y-6">
        {history.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 pt-12 md:pt-24 opacity-80 animate-in fade-in duration-700">
            <div className="w-20 h-20 bg-[#D8F3DC] dark:bg-emerald-900/40 border-2 border-white dark:border-slate-800 shadow-sm rounded-full flex items-center justify-center text-[#40916C] dark:text-emerald-300 mb-4 pb-1 transition-colors">
              <ChefHat className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-semibold text-[#1B4332] dark:text-emerald-50 transition-colors">Halo, saya Nutri! 👋</h2>
            <p className="max-w-md text-[#525B58] dark:text-slate-400 transition-colors">
              Kirim nama makanan Indonesia atau foto hidanganmu, dan saya akan bantu cek kandungan gizinya dengan cepat dan mudah dipahami.
            </p>
            <div className="flex flex-wrap justify-center gap-2 mt-4 text-[10px] sm:text-xs text-[#40916C] dark:text-emerald-300 font-bold uppercase tracking-wider transition-colors">
              <span className="bg-[#E9F5EE] dark:bg-emerald-900/30 px-3 py-1.5 rounded-full border border-[#B7E4C7] dark:border-emerald-800/50">"Kalori Nasi Goreng"</span>
              <span className="bg-[#E9F5EE] dark:bg-emerald-900/30 px-3 py-1.5 rounded-full border border-[#B7E4C7] dark:border-emerald-800/50">"Kandungan Gado-Gado"</span>
              <span className="bg-[#E9F5EE] dark:bg-emerald-900/30 px-3 py-1.5 rounded-full border border-[#B7E4C7] dark:border-emerald-800/50">📷 Upload Foto</span>
            </div>
          </div>
        ) : (
          history.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
            >
              <div
                className={`max-w-[90%] md:max-w-[80%] rounded-2xl p-5 shadow-sm transition-colors ${
                  msg.role === "user"
                    ? "bg-[#40916C] dark:bg-emerald-600 text-white rounded-tr-none"
                    : "bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 text-[#2D3436] dark:text-slate-200 rounded-tl-none"
                }`}
              >
                {msg.parts.map((p, idx) => {
                  const hasText = !!p.text;
                  const extracted = hasText ? extractNutritionData(p.text!) : { data: null, cleanText: "" };

                  return (
                    <div key={idx} className="space-y-3">
                      {p.inlineData && (
                        <img
                          src={`data:${p.inlineData.mimeType};base64,${p.inlineData.data}`}
                          className="max-w-xs md:max-w-sm rounded-xl"
                          alt="Uploaded food"
                        />
                      )}
                      {hasText && (
                        <div className={`prose prose-sm md:prose-base ${msg.role === "user" ? "prose-invert" : "dark:prose-invert"} max-w-none break-words`}>
                          <ReactMarkdown>{extracted.cleanText}</ReactMarkdown>
                        </div>
                      )}
                      {extracted.data && msg.role === "model" && (
                        <div className="space-y-4">
                          <NutritionChart data={extracted.data} dailyTargets={dailyTargets} />
                          {!extracted.data.consumed ? (
                            <div className="flex justify-end pt-2 border-t border-[#EDF2F0] dark:border-slate-800 mt-4">
                              <button 
                                onClick={() => markAsConsumed(i)}
                                className="text-xs font-semibold bg-[#E9F5EE] hover:bg-[#D8EADB] dark:bg-emerald-900/40 dark:hover:bg-emerald-800/60 text-[#2D6A4F] dark:text-emerald-300 py-2 px-4 rounded-lg transition-colors border border-[#B7E4C7] dark:border-emerald-800/50"
                              >
                                ✓ Saya konsumsi ini
                              </button>
                            </div>
                          ) : (
                            <div className="flex justify-end pt-2 mt-4">
                              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 opacity-75">
                                ✓ Masuk ke laporan harian
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ))
        )}

        {isLoading && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="flex justify-start w-full md:w-[80%]"
          >
            <div className="w-full bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-2xl rounded-tl-none p-5 shadow-sm transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <ChefHat className="text-[#40916C] dark:text-emerald-400 w-5 h-5 animate-pulse" />
                <span className="text-sm font-medium text-[#525B58] dark:text-slate-400 animate-pulse">Nutri sedang meracik jawaban...</span>
              </div>
              <div className="space-y-3 animate-pulse">
                <div className="h-4 bg-[#EDF2F0] dark:bg-slate-800 rounded-full w-3/4"></div>
                <div className="h-4 bg-[#EDF2F0] dark:bg-slate-800 rounded-full w-full"></div>
                <div className="h-4 bg-[#EDF2F0] dark:bg-slate-800 rounded-full w-5/6"></div>
                <div className="h-4 bg-[#EDF2F0] dark:bg-slate-800 rounded-full w-1/2"></div>
              </div>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* Input Area */}
      <footer className="p-6 bg-[#F8F9F9] dark:bg-slate-950/50 border-t border-[#EDF2F0] dark:border-slate-800 sticky bottom-0 shrink-0 transition-colors">
        <div className="max-w-4xl mx-auto flex flex-col gap-3">
          {imagePreview && (
            <div className="relative w-max">
              <img
                src={imagePreview}
                alt="Preview"
                className="h-24 max-w-xs object-cover rounded-2xl border-2 border-dashed border-[#D1D8D5] dark:border-slate-700"
              />
              <button
                type="button"
                onClick={removeImage}
                className="absolute -top-3 -right-3 bg-[#2D3436] dark:bg-slate-700 text-white rounded-full p-1.5 hover:bg-[#C0392B] dark:hover:bg-red-500 transition-colors shadow-md"
                aria-label="Remove image"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <form
            onSubmit={handleSubmit}
            className="relative flex items-end bg-white dark:bg-slate-900 border border-[#D1D8D5] dark:border-slate-700 rounded-2xl p-1 shadow-sm focus-within:ring-2 focus-within:ring-[#40916C] dark:focus-within:ring-emerald-500 focus-within:border-transparent transition-all"
          >
            <label
              htmlFor="image-upload"
              className="shrink-0 p-3 text-[#95A5A6] dark:text-slate-500 hover:text-[#40916C] dark:hover:text-emerald-400 hover:bg-[#F0F2F1] dark:hover:bg-slate-800 rounded-xl cursor-pointer transition-colors mb-0.5"
            >
              <ImageIcon className="w-6 h-6" />
              <input
                id="image-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageChange}
              />
            </label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              placeholder="Tanya apa saja tentang gizi makanan lokal..."
              className="flex-1 max-h-32 min-h-[44px] bg-transparent outline-none resize-none py-3.5 px-2 text-[#2D3436] dark:text-slate-200 placeholder:text-[#95A5A6] dark:placeholder:text-slate-500 leading-relaxed mb-0.5"
              rows={Math.min(input.split("\n").length, 4) || 1}
            />
            <div className="flex shrink-0 gap-2 mb-0.5 mr-0.5 p-1">
              <button
                type="submit"
                disabled={(!input.trim() && !imageFile) || isLoading}
                className="bg-[#40916C] dark:bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-semibold shadow-sm hover:bg-[#2D6A4F] dark:hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-[#40916C] dark:disabled:hover:bg-emerald-600 transition-colors flex items-center justify-center"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </form>
        </div>
      </footer>

      {/* Profile/Targets Modal */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm dark:bg-black/60 animate-in fade-in duration-200">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md shadow-xl border border-[#EDF2F0] dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="flex justify-between items-center p-6 border-b border-[#EDF2F0] dark:border-slate-800 shrink-0">
              <h2 className="text-xl font-bold flex items-center gap-2 text-[#1B4332] dark:text-emerald-50">
                <Settings2 className="w-5 h-5" /> Target Gizi Harian
              </h2>
              <button onClick={() => setIsProfileModalOpen(false)} className="text-[#95A5A6] hover:text-[#2D3436] dark:hover:text-slate-200 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-4">
              <p className="text-sm text-[#525B58] dark:text-slate-400 mb-2">Sesuaikan target harianmu agar analisis gizi Nutri lebih personal.</p>
              
              <div className="space-y-4">
                {[
                  { key: 'calories', label: 'Kalori', unit: 'kkal', max: 5000 },
                  { key: 'protein', label: 'Protein', unit: 'g', max: 300 },
                  { key: 'carbs', label: 'Karbohidrat', unit: 'g', max: 600 },
                  { key: 'fat', label: 'Lemak', unit: 'g', max: 200 },
                  { key: 'fiber', label: 'Serat', unit: 'g', max: 100 },
                  { key: 'sodium', label: 'Natrium (Max)', unit: 'mg', max: 5000 },
                  { key: 'sugar', label: 'Gula (Max)', unit: 'g', max: 200 },
                ].map(({ key, label, unit, max }) => (
                  <div key={key} className="bg-[#F9FAF8] dark:bg-slate-950 p-4 rounded-2xl border border-[#EDF2F0] dark:border-slate-800">
                    <div className="flex justify-between mb-2">
                       <label className="text-sm font-semibold text-[#2D3436] dark:text-slate-200">{label}</label>
                       <span className="text-xs font-medium text-[#40916C] dark:text-emerald-400 bg-[#E9F5EE] dark:bg-emerald-900/30 px-2 py-0.5 rounded-full">{tempTargets[key as keyof NutritionData]} {unit}</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max={max}
                      step={key === 'calories' || key === 'sodium' ? 50 : 5}
                      value={tempTargets[key as keyof NutritionData]}
                      onChange={(e) => setTempTargets({...tempTargets, [key]: Number(e.target.value)})}
                      className="w-full accent-[#40916C]"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 border-t border-[#EDF2F0] dark:border-slate-800 shrink-0 flex gap-3">
               <button 
                  onClick={() => setTempTargets(DEFAULT_TARGETS)}
                  className="flex-1 py-3 px-4 rounded-xl font-semibold text-[#525B58] dark:text-slate-400 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors"
                >
                  Reset Default
                </button>
                <button 
                  onClick={handleSaveProfile}
                  className="flex-1 py-3 px-4 rounded-xl font-semibold text-white bg-[#40916C] hover:bg-[#2D6A4F] dark:bg-emerald-600 dark:hover:bg-emerald-700 transition-colors flex justify-center items-center gap-2 shadow-sm"
                >
                  <Save className="w-4 h-4" /> Simpan
                </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}