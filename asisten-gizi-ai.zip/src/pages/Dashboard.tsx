import { useAuth } from "../contexts/AuthContext";
import { Navigate, Link } from "react-router-dom";
import { ChefHat, LogOut, ArrowRight, Activity, Moon, Sun, Utensils } from "lucide-react";
import { motion } from "motion/react";
import NutritionChart, { NutritionData } from "../components/NutritionChart";
import WeeklySummaryChart from "../components/WeeklySummaryChart";
import { useState, useEffect } from "react";
import { UserProfile } from "../contexts/AuthContext";
import ProfileSettings from "../components/ProfileSettings";
import { useTheme } from "../contexts/ThemeContext";
import Markdown from "react-markdown";

export default function Dashboard() {
  const { user, profile, logOut } = useAuth();
  const { isDarkMode, toggleDarkMode } = useTheme();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>(() => new Date().toISOString().split("T")[0]);
  const [dailyNutrition, setDailyNutrition] = useState<NutritionData>({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0,
    sodium: 0,
    sugar: 0,
  });
  const [consumedFoods, setConsumedFoods] = useState<any[]>([]);
  const [weeklyData, setWeeklyData] = useState<any[]>([]);
  const [isGeneratingRecipe, setIsGeneratingRecipe] = useState(false);
  const [recipeSuggestions, setRecipeSuggestions] = useState<string>("");

  const generateRecipe = async () => {
    setIsGeneratingRecipe(true);
    setRecipeSuggestions("");
    
    try {
      const saved = localStorage.getItem("nutri_chat_history");
      const foods: string[] = [];
      if (saved) {
        const history = JSON.parse(saved);
        history.forEach((msg: any) => {
          if (msg.role === "model" && msg.parts && msg.parts[0] && msg.parts[0].text) {
             const match = msg.parts[0].text.match(/```json\n([\s\S]*?)\n```/);
             if (match && match[1]) {
               try {
                 const data = JSON.parse(match[1]);
                 if (data && data.consumed) {
                   const cleanText = msg.parts[0].text.replace(/```json\n[\s\S]*?\n```/, '').trim();
                   // Take the first line or a short description to avoid too long texts
                   foods.push(cleanText.split('\n')[0].substring(0, 50));
                 }
               } catch (e) {}
             }
          }
        });
      }
      
      const foodContext = foods.length > 0 
        ? `Makanan yang sering dikonsumsi: ${foods.slice(0, 20).join(", ")}.` // Limit to recent 20 for context
        : "Belum banyak riwayat makanan.";
      
      const prompt = `${foodContext}\nBerdasarkan daftar makanan yang sering dikonsumsi pengguna tersebut, berikan 3 saran resep sehat dan bergizi yang mudah dibuat. Berikan bahan-bahan dan cara singkat pembuatannya. Format dengan rapi menggunakan Markdown. Jangan sertakan json di output.`;

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          history: [], 
          message: prompt 
        }),
      });

      const data = await response.json();
      if (data.text) {
        setRecipeSuggestions(data.text);
      } else {
        setRecipeSuggestions("Gagal mendapatkan saran resep. Coba lagi.");
      }
    } catch (error) {
      setRecipeSuggestions("Terjadi kesalahan jaringan.");
    } finally {
      setIsGeneratingRecipe(false);
    }
  };

  useEffect(() => {
    try {
      const saved = localStorage.getItem("nutri_chat_history");
      if (saved) {
        const history = JSON.parse(saved);
        let totals = { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sodium: 0, sugar: 0 };
        const foods: any[] = [];
        
        // Prepare weekly data map
        const weeklyMap: Record<string, { calories: number; protein: number; carbs: number; fat: number; }> = {};
        for (let i = 6; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const dateStr = d.toISOString().split("T")[0];
          weeklyMap[dateStr] = { calories: 0, protein: 0, carbs: 0, fat: 0 };
        }
        
        history.forEach((msg: any) => {
          if (msg.role === "model" && msg.parts && msg.parts[0] && msg.parts[0].text) {
             const msgDate = msg.timestamp ? new Date(msg.timestamp).toISOString().split("T")[0] : new Date().toISOString().split("T")[0];
             
             const match = msg.parts[0].text.match(/```json\n([\s\S]*?)\n```/);
             if (match && match[1]) {
               try {
                 const data = JSON.parse(match[1]);
                 if (data && data.consumed) {
                   if (msgDate === selectedDate) {
                     totals.calories += data.calories || 0;
                     totals.protein += data.protein || 0;
                     totals.carbs += data.carbs || 0;
                     totals.fat += data.fat || 0;
                     totals.fiber += data.fiber || 0;
                     totals.sodium += data.sodium || 0;
                     totals.sugar += data.sugar || 0;
                     
                     // Extract food name assuming it's above the JSON block
                     const cleanText = msg.parts[0].text.replace(/```json\n[\s\S]*?\n```/, '').trim();
                     foods.push({
                       data,
                       text: cleanText,
                       timestamp: msg.timestamp || Date.now()
                     });
                   }
                   
                   if (weeklyMap[msgDate]) {
                     weeklyMap[msgDate].calories += data.calories || 0;
                     weeklyMap[msgDate].protein += data.protein || 0;
                     weeklyMap[msgDate].carbs += data.carbs || 0;
                     weeklyMap[msgDate].fat += data.fat || 0;
                   }
                 }
               } catch (e) {}
             }
          }
        });
        
        setDailyNutrition(totals);
        setConsumedFoods(foods.sort((a, b) => b.timestamp - a.timestamp));
        
        const formattedWeeklyData = Object.keys(weeklyMap).map(dateStr => {
          const [, m, d] = dateStr.split("-");
          return {
            date: `${d}/${m}`,
            ...weeklyMap[dateStr]
          };
        });
        setWeeklyData(formattedWeeklyData);
      }
    } catch (e) {}
  }, [selectedDate]);

  
  if (!user || !profile) {
    return <Navigate to="/login" replace />;
  }

  // Calculate TDEE/BMR
  const calculateTDEE = (p: Partial<UserProfile> | null) => {
    if (!p || !p.weight || !p.height || !p.age || !p.gender || !p.activityLevel) return 0;
    // Mifflin-St Jeor Equation
    let bmr = (10 * p.weight) + (6.25 * p.height) - (5 * p.age);
    bmr += p.gender === 'male' ? 5 : -161;
    let tdee = bmr * p.activityLevel;
    
    // Adjust based on health goal
    if (p.healthGoal === 'weight_loss') tdee -= 500;
    if (p.healthGoal === 'muscle_building') tdee += 500;

    return Math.max(1200, Math.round(tdee)); // minimum 1200 calories
  };
  
  const estimatedTDEE = calculateTDEE(profile);

  return (
    <div className="min-h-screen bg-[#F9FAF8] dark:bg-slate-950 font-sans text-[#2D3436] dark:text-slate-200 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-[#EDF2F0] dark:border-slate-800 px-6 py-4 flex justify-between items-center sticky top-0 z-40 transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#40916C] dark:bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-sm transition-colors">
            <ChefHat className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-[#1B4332] dark:text-emerald-50">
            Nutri <span className="text-[#74C69D] dark:text-emerald-400 font-normal">Dashboard</span>
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={toggleDarkMode}
            className="w-8 h-8 flex items-center justify-center rounded-xl text-[#95A5A6] dark:text-slate-400 hover:bg-[#F0F2F1] dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle dark mode"
          >
            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          <span className="text-sm font-medium text-[#525B58] dark:text-slate-400 hidden sm:inline">
            {profile.displayName}
          </span>
          <button
            onClick={logOut}
            className="flex items-center gap-2 text-sm text-[#E63946] hover:bg-red-50 dark:hover:bg-red-900/20 px-3 py-1.5 rounded-xl transition-colors"
          >
            <LogOut className="w-4 h-4" /> <span className="hidden sm:inline">Keluar</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-6 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="col-span-1 md:col-span-2 bg-[#1B4332] dark:bg-emerald-900 rounded-3xl p-8 relative overflow-hidden flex flex-col justify-center"
          >
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <ChefHat className="w-48 h-48 text-white" />
            </div>
            <div className="relative z-10 text-white">
              <h2 className="text-3xl font-bold mb-2">Halo, {profile.displayName.split(" ")[0]}!</h2>
              <p className="text-emerald-100 mb-6 max-w-sm">Siap untuk memantau asupan gizi hari ini? Nutri AI siap membantu menganalisis makananmu.</p>
              <Link 
                to="/chat" 
                className="inline-flex items-center gap-2 bg-emerald-400 hover:bg-emerald-300 text-emerald-950 font-bold py-3 px-6 rounded-xl transition-colors"
                title="Mulai Chat Baru"
              >
                Mulai Chat Nutri AI <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex border-b border-[#EDF2F0] dark:border-slate-800 pb-4 mb-4 gap-3 items-center">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-900/50 text-[#1B4332] dark:text-emerald-400 rounded-lg">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2D3436] dark:text-slate-200">BMR & TDEE</h3>
                  <p className="text-xs text-[#525B58] dark:text-slate-400">Estimasi Kebutuhan Kalori</p>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#525B58] dark:text-slate-400">Target Kamu:</span>
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                    {profile.healthGoal === "weight_loss" ? "Weight Loss" : profile.healthGoal === "muscle_building" ? "Muscle Build" : "Maintenance"}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#525B58] dark:text-slate-400">Estimasi TDEE:</span>
                  <span className="font-bold text-lg text-[#2D3436] dark:text-slate-200">{estimatedTDEE} <span className="text-sm font-normal">kkal</span></span>
                </div>
                <div className="flex justify-between items-center">
                   <span className="text-sm text-[#525B58] dark:text-slate-400">Target Sistem:</span>
                   <span className="font-bold text-lg text-[#2D3436] dark:text-slate-200">{profile.dailyTargets.calories} <span className="text-sm font-normal">kkal</span></span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsSettingsOpen(true)} className="text-sm font-medium text-[#40916C] dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 mt-4 inline-block text-center bg-emerald-50 dark:bg-emerald-900/20 py-2 rounded-lg w-full">
              Ubah Data Fisik & Tujuan
            </button>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-sm flex flex-col"
        >
           <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4 border-b border-[#EDF2F0] dark:border-slate-800 pb-6">
              <div>
                <h2 className="text-2xl font-bold text-[#1B4332] dark:text-emerald-50 mb-1">Riwayat Nutrisi Harian</h2>
                <p className="text-[#525B58] dark:text-slate-400 text-sm">Akumulasi asupan gizimu berdasarkan makanan yang dikonsumsi.</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 self-start md:self-auto items-center">
                <button
                  onClick={() => {
                    const d = new Date(selectedDate);
                    d.setDate(d.getDate() - 1);
                    setSelectedDate(d.toISOString().split("T")[0]);
                  }}
                  className="p-2 text-[#95A5A6] hover:text-[#2D3436] dark:hover:text-slate-200 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl transition-colors"
                >
                  &larr;
                </button>
                <div className="flex gap-2">
                  <select
                    value={selectedDate.split("-")[2]}
                    onChange={(e) => {
                      const parts = selectedDate.split("-");
                      parts[2] = e.target.value;
                      setSelectedDate(parts.join("-"));
                    }}
                    className="bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 text-[#2D3436] dark:text-slate-200 rounded-xl px-2 sm:px-4 py-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#40916C] dark:focus:ring-emerald-500 cursor-pointer appearance-none text-center"
                  >
                    {Array.from({ length: new Date(parseInt(selectedDate.split("-")[0]), parseInt(selectedDate.split("-")[1]), 0).getDate() || 31 }, (_, i) => i + 1).map(d => {
                      const val = d.toString().padStart(2, '0');
                      return <option key={val} value={val}>{val}</option>;
                    })}
                  </select>
                  <select
                    value={selectedDate.split("-")[1]}
                    onChange={(e) => {
                      const parts = selectedDate.split("-");
                      parts[1] = e.target.value;
                      
                      const year = parseInt(parts[0]);
                      const month = parseInt(parts[1]);
                      const maxDays = new Date(year, month, 0).getDate();
                      
                      if (parseInt(parts[2]) > maxDays) {
                         parts[2] = maxDays.toString().padStart(2, '0');
                      }
                      
                      setSelectedDate(parts.join("-"));
                    }}
                    className="bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 text-[#2D3436] dark:text-slate-200 rounded-xl px-2 sm:px-4 py-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#40916C] dark:focus:ring-emerald-500 cursor-pointer appearance-none text-center"
                  >
                    {[
                      { v: "01", l: "Jan" }, { v: "02", l: "Feb" }, { v: "03", l: "Mar" }, { v: "04", l: "Apr" },
                      { v: "05", l: "Mei" }, { v: "06", l: "Jun" }, { v: "07", l: "Jul" }, { v: "08", l: "Ags" },
                      { v: "09", l: "Sep" }, { v: "10", l: "Okt" }, { v: "11", l: "Nov" }, { v: "12", l: "Des" }
                    ].map(m => (
                      <option key={m.v} value={m.v}>{m.l}</option>
                    ))}
                  </select>
                  <select
                    value={selectedDate.split("-")[0]}
                    onChange={(e) => {
                      const parts = selectedDate.split("-");
                      parts[0] = e.target.value;
                      
                      const year = parseInt(parts[0]);
                      const month = parseInt(parts[1]);
                      const maxDays = new Date(year, month, 0).getDate();
                      
                      if (parseInt(parts[2]) > maxDays) {
                         parts[2] = maxDays.toString().padStart(2, '0');
                      }
                      
                      setSelectedDate(parts.join("-"));
                    }}
                    className="bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 text-[#2D3436] dark:text-slate-200 rounded-xl px-2 sm:px-4 py-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#40916C] dark:focus:ring-emerald-500 cursor-pointer appearance-none text-center"
                  >
                    {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(y => (
                      <option key={y} value={y.toString()}>{y}</option>
                    ))}
                  </select>
                </div>
                <button
                  disabled={selectedDate === new Date().toISOString().split("T")[0]}
                  onClick={() => {
                    const d = new Date(selectedDate);
                    d.setDate(d.getDate() + 1);
                    setSelectedDate(d.toISOString().split("T")[0]);
                  }}
                  className="p-2 text-[#95A5A6] hover:text-[#2D3436] dark:hover:text-slate-200 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-xl disabled:opacity-50 transition-colors"
                >
                  &rarr;
                </button>
                <Link to="/chat" className="text-sm font-semibold text-[#40916C] dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 bg-emerald-50 dark:bg-emerald-900/20 px-4 py-2.5 rounded-xl whitespace-nowrap transition-colors flex items-center justify-center gap-2">
                  Sesuaikan Target
                </Link>
              </div>
           </div>
           
           <div className="max-w-4xl mx-auto w-full space-y-8">
             <NutritionChart data={dailyNutrition} dailyTargets={profile.dailyTargets} />
             
             {consumedFoods.length > 0 && (
               <div className="mt-8">
                 <h3 className="text-lg font-bold text-[#1B4332] dark:text-emerald-50 mb-4">Konsumsi pada {selectedDate}</h3>
                 <div className="space-y-4">
                   {consumedFoods.map((food, idx) => (
                     <div key={idx} className="bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row justify-between md:items-center gap-4">
                       <div className="flex-1">
                         <div className="text-sm text-[#2D3436] dark:text-slate-200 prose prose-sm dark:prose-invert line-clamp-2">
                           {food.text || "Makanan Terdata"}
                         </div>
                         <div className="text-xs text-[#95A5A6] mt-2">
                           {new Date(food.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                         </div>
                       </div>
                       <div className="flex flex-wrap gap-2 shrink-0">
                         <span className="text-xs font-semibold px-2 py-1 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg whitespace-nowrap">Kal: {food.data.calories}</span>
                         <span className="text-xs font-semibold px-2 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg whitespace-nowrap">Pro: {food.data.protein}g</span>
                         <span className="text-xs font-semibold px-2 py-1 bg-yellow-50 dark:bg-yellow-900/20 text-yellow-600 dark:text-yellow-400 rounded-lg whitespace-nowrap">Kar: {food.data.carbs}g</span>
                         <span className="text-xs font-semibold px-2 py-1 bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 rounded-lg whitespace-nowrap">Lem: {food.data.fat}g</span>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
             )}
             
             {consumedFoods.length === 0 && (
               <div className="text-center py-8">
                 <p className="text-[#525B58] dark:text-slate-400">Tidak ada catatan makanan untuk tanggal ini.</p>
               </div>
             )}
           </div>
        </motion.div>

        {/* Ringkasan Gizi Mingguan */}
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 0.25 }}
           className="bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-sm flex flex-col mb-8"
        >
           <div className="mb-6 border-b border-[#EDF2F0] dark:border-slate-800 pb-6">
             <h2 className="text-2xl font-bold text-[#1B4332] dark:text-emerald-50 mb-1 flex items-center gap-2">
               <Activity className="w-6 h-6 text-[#40916C] dark:text-emerald-400" />
               Tren Gizi Mingguan
             </h2>
             <p className="text-[#525B58] dark:text-slate-400 text-sm">Pola asupan kalori dan makronutrisi selama 7 hari terakhir.</p>
           </div>
           
           <div className="w-full">
             {weeklyData.length > 0 ? (
               <WeeklySummaryChart data={weeklyData} />
             ) : (
               <div className="text-center py-8">
                 <p className="text-[#525B58] dark:text-slate-400">Belum ada data untuk grafik mingguan.</p>
               </div>
             )}
           </div>
        </motion.div>

        {/* Saran Resep Sehat */}
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 0.3 }}
           className="bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-sm flex flex-col"
        >
           <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4 border-b border-[#EDF2F0] dark:border-slate-800 pb-6">
              <div>
                <h2 className="text-2xl font-bold text-[#1B4332] dark:text-emerald-50 mb-1 flex items-center gap-2">
                  <Utensils className="w-6 h-6 text-[#40916C] dark:text-emerald-400" />
                  Saran Resep Sehat
                </h2>
                <p className="text-[#525B58] dark:text-slate-400 text-sm">Dapatkan inspirasi menu bergizi berbasis makanan favoritmu.</p>
              </div>
              <button
                onClick={generateRecipe}
                disabled={isGeneratingRecipe}
                className="text-sm font-semibold text-white bg-[#40916C] hover:bg-[#2D6A4F] dark:bg-emerald-600 dark:hover:bg-emerald-500 px-6 py-3 rounded-xl whitespace-nowrap transition-colors flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isGeneratingRecipe ? (
                  <>
                     <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin"></span>
                     Meracik Resep...
                  </>
                ) : (
                  "Buat Saran Resep"
                )}
              </button>
           </div>
           
           <div className="w-full">
             {recipeSuggestions ? (
               <div className="bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-2xl p-6 prose prose-emerald dark:prose-invert max-w-none text-sm md:text-base">
                 <Markdown>{recipeSuggestions}</Markdown>
               </div>
             ) : (
               <div className="text-center py-10 bg-[#F9FAF8] dark:bg-slate-950 border border-[#EDF2F0] dark:border-slate-800 rounded-2xl border-dashed">
                 <ChefHat className="w-12 h-12 text-[#95A5A6] mx-auto mb-4 opacity-50" />
                 <p className="text-[#525B58] dark:text-slate-400 font-medium">Klik tombol di atas untuk mendapatkan resep berdasarkan riwayat asupan gizimu.</p>
               </div>
             )}
           </div>
        </motion.div>

      </main>

      {/* Settings Modal */}
      <ProfileSettings 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
      />
    </div>
  );
}
