import { useAuth } from "../contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { ChefHat, Chrome } from "lucide-react";
import { motion } from "motion/react";

export default function Login() {
  const { user, profile, signIn, logOut } = useAuth();

  if (user && profile) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F9FAF8] dark:bg-slate-950 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white dark:bg-slate-900 border border-[#EDF2F0] dark:border-slate-800 rounded-3xl p-8 shadow-sm text-center"
      >
        <div className="w-20 h-20 bg-[#D8F3DC] dark:bg-emerald-900/40 border-2 border-white dark:border-slate-800 shadow-sm rounded-full flex items-center justify-center text-[#40916C] dark:text-emerald-300 mx-auto mb-6">
          <ChefHat className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-bold text-[#1B4332] dark:text-emerald-50 tracking-tight mb-2">Nutri AI</h1>
        <p className="text-[#525B58] dark:text-slate-400 mb-8">
          {user && !profile 
            ? "Gagal memuat profil. Silakan coba lagi atau daftar ulang." 
            : "Masuk untuk akses fitur analisa nutrisi makanan dan rekam jejak gizimu."}
        </p>
        
        {user && !profile ? (
          <button
            onClick={logOut}
            className="w-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/30 py-3.5 px-4 rounded-xl font-semibold shadow-sm hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors flex items-center justify-center gap-3"
          >
            Keluar dan Coba Lagi
          </button>
        ) : (
          <button
            onClick={signIn}
            className="w-full bg-white dark:bg-slate-800 border border-[#D1D8D5] dark:border-slate-700 text-[#2D3436] dark:text-slate-200 py-3.5 px-4 rounded-xl font-semibold shadow-sm hover:bg-[#F8F9F9] dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-3"
          >
            <Chrome className="w-5 h-5 text-current" /> Lanjutkan dengan Google
          </button>
        )}
      </motion.div>
    </div>
  );
}
